Twitter4J を使ったアプリケーション、サービスでは任意で以下のバッジを使用することができます。バッジのライセンスは BSD です。リンクする場合は "http://twitter4j.org/" へリンクして頂くようお願いいたします。。

HTML コード例:
PNG:
- 枠無し
<a href="http://twitter4j.org/"><img src="./images/powered-by-twitter4j-138x30.png" border="0" width="122" height="30"></a>

- 枠有り
<a href="http://twitter4j.org/"><img src="./images/powered-by-twitter4j-border-138x30.png" border="0" width="122" height="30"></a>


GIF:
- 枠無し
<a href="http://twitter4j.org/"><img src="./images/powered-by-twitter4j-138x30.gif" border="0" width="122" height="30"></a>

- 枠有り
<a href="http://twitter4j.org/"><img src="./images/powered-by-twitter4j-border-138x30.gif" border="0" width="122" height="30"></a>

